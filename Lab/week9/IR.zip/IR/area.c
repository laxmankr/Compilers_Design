int height;
int base;
float area;
area=heigth*base/2;
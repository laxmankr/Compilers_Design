int principal;
int rate;
int years;
float interest;
principal=5000;
rate=8;
years=5;
interest=principal*rate*years/100;